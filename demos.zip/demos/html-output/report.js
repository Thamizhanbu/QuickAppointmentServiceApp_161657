$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/capgemini/demos/formdef/form.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Kishore"
    }
  ],
  "line": 4,
  "name": "Form Registration",
  "description": "",
  "id": "form-registration",
  "keyword": "Feature",
  "tags": [
    {
      "line": 3,
      "name": "@form"
    }
  ]
});
formatter.background({
  "line": 6,
  "name": "User has already in the form page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 7,
  "name": "User in form page",
  "keyword": "Given "
});
formatter.match({
  "location": "FormDef.user_in_form_page()"
});
formatter.result({
  "duration": 5249915084,
  "status": "passed"
});
formatter.scenario({
  "line": 9,
  "name": "Form submission failed due to first name is empty",
  "description": "",
  "id": "form-registration;form-submission-failed-due-to-first-name-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 10,
  "name": "first name is empty",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "submitting the form",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "display the error message",
  "keyword": "Then "
});
formatter.match({
  "location": "FormDef.first_name_is_empty()"
});
formatter.result({
  "duration": 59174049,
  "status": "passed"
});
formatter.match({
  "location": "FormDef.submitting_the_form()"
});
formatter.result({
  "duration": 88984233,
  "status": "passed"
});
formatter.match({
  "location": "FormDef.display_the_error_message()"
});
formatter.result({
  "duration": 6074797639,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "User has already in the form page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 7,
  "name": "User in form page",
  "keyword": "Given "
});
formatter.match({
  "location": "FormDef.user_in_form_page()"
});
formatter.result({
  "duration": 2975167000,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Form submission failed due to city is empty",
  "description": "",
  "id": "form-registration;form-submission-failed-due-to-city-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "city is empty",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "submitting the form",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "display the error message of city",
  "keyword": "Then "
});
formatter.match({
  "location": "FormDef.city_is_empty()"
});
formatter.result({
  "duration": 2167194891,
  "status": "passed"
});
formatter.match({
  "location": "FormDef.submitting_the_form()"
});
formatter.result({
  "duration": 112919264,
  "status": "passed"
});
formatter.match({
  "location": "FormDef.display_the_error_message_of_city()"
});
formatter.result({
  "duration": 4318642307,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "User has already in the form page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 7,
  "name": "User in form page",
  "keyword": "Given "
});
formatter.match({
  "location": "FormDef.user_in_form_page()"
});
formatter.result({
  "duration": 2769690498,
  "status": "passed"
});
formatter.scenario({
  "line": 19,
  "name": "Form submission failed due to password is empty",
  "description": "",
  "id": "form-registration;form-submission-failed-due-to-password-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 20,
  "name": "password is empty",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "submitting the form",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "display the error message of password",
  "keyword": "Then "
});
formatter.match({
  "location": "FormDef.password_is_empty()"
});
formatter.result({
  "duration": 2211404983,
  "status": "passed"
});
formatter.match({
  "location": "FormDef.submitting_the_form()"
});
formatter.result({
  "duration": 95438614,
  "status": "passed"
});
formatter.match({
  "location": "FormDef.display_the_error_message_of_password()"
});
formatter.result({
  "duration": 6110901399,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "User has already in the form page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 7,
  "name": "User in form page",
  "keyword": "Given "
});
formatter.match({
  "location": "FormDef.user_in_form_page()"
});
formatter.result({
  "duration": 2937157365,
  "status": "passed"
});
formatter.scenario({
  "line": 24,
  "name": "Form submission failed due to gender is not clicked",
  "description": "",
  "id": "form-registration;form-submission-failed-due-to-gender-is-not-clicked",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 25,
  "name": "Gender is not clicked",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "submitting the form",
  "keyword": "And "
});
formatter.step({
  "line": 27,
  "name": "display the error message of gender",
  "keyword": "Then "
});
formatter.match({
  "location": "FormDef.gender_is_not_clicked()"
});
formatter.result({
  "duration": 2215036239,
  "status": "passed"
});
formatter.match({
  "location": "FormDef.submitting_the_form()"
});
formatter.result({
  "duration": 133353489,
  "status": "passed"
});
formatter.match({
  "location": "FormDef.display_the_error_message_of_gender()"
});
formatter.result({
  "duration": 4150641746,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "User has already in the form page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 7,
  "name": "User in form page",
  "keyword": "Given "
});
formatter.match({
  "location": "FormDef.user_in_form_page()"
});
formatter.result({
  "duration": 2857649184,
  "status": "passed"
});
formatter.scenario({
  "line": 29,
  "name": "Form submission failed due to language is not checked",
  "description": "",
  "id": "form-registration;form-submission-failed-due-to-language-is-not-checked",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 30,
  "name": "language is not checked",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "submitting the form",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "display the error message of language",
  "keyword": "Then "
});
formatter.match({
  "location": "FormDef.language_is_not_checked()"
});
formatter.result({
  "duration": 2280981358,
  "status": "passed"
});
formatter.match({
  "location": "FormDef.submitting_the_form()"
});
formatter.result({
  "duration": 89912148,
  "status": "passed"
});
formatter.match({
  "location": "FormDef.display_the_error_message_of_language()"
});
formatter.result({
  "duration": 4167153460,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "User has already in the form page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 7,
  "name": "User in form page",
  "keyword": "Given "
});
formatter.match({
  "location": "FormDef.user_in_form_page()"
});
formatter.result({
  "duration": 2877629707,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "Form submission failed due to mynumber is empty",
  "description": "",
  "id": "form-registration;form-submission-failed-due-to-mynumber-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "mynumber is empty",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "submitting the form",
  "keyword": "And "
});
formatter.step({
  "line": 37,
  "name": "display the error message of mynumber",
  "keyword": "Then "
});
formatter.match({
  "location": "FormDef.mynumber_is_empty()"
});
