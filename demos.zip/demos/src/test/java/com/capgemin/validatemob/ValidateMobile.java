package com.capgemin.validatemob;

import java.util.ArrayList; 
import java.util.Iterator;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class ValidateMobile {
	
	List<String> mobno = new ArrayList<>();
	@Given("^Add mobileno in list$")
	public void add_mobileno_in_list(DataTable arg1) throws Throwable {
	   
		mobno = arg1.asList(String.class);
		Iterator<String> it = mobno.iterator();
		while(it.hasNext()) {
			String mobile = it.next();
			if(mobile.matches("[4-9][0-9]{9}")) {
				System.out.println("Valid MobileNo: "+mobile);
			}else {
				System.out.println("Invalid MobileNo: "+mobile);
			}
		}
	}


	@Then("^print the output$")
	public void print_the_output() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Printing the output : "+mobno);
	}


}
