package com.capgemin.validatemob;

import java.util.Scanner;

import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import demos.Customer;

public class CheckBalance { 
	Customer customer = new Customer();
	Scanner scan = new Scanner(System.in);
	
	@Given("^Enter Customer Details$")
	public void enter_Customer_Details() throws Throwable {
	   System.out.println("Enter Name: ");
	   customer.setName(scan.next());
	   System.out.println("Enter MobileNo: ");
	   customer.setMobileno(scan.next());
	   System.out.println("Enter City: ");
	   customer.setCity(scan.next());
	   System.out.println("Enter Balance: ");
	   customer.setBalance(scan.nextInt());
	}

	@When("^Check the Balance$")
	public void check_the_Balance() throws Throwable {
	   Assert.assertTrue(customer.getBalance()>=500);
	}

	@Then("^Print the Customer Details$")
	public void print_the_Customer_Details() throws Throwable {
	    System.out.println(customer);
	}
	

@Given("^Getting the Balance$")
public void getting_the_Balance() throws Throwable {
   customer.getBalance();
}

@When("^Balance is low$")
public void balance_is_low() throws Throwable {
   Assert.assertTrue(customer.getBalance()<500);
}

@Then("^print error message$")
public void print_error_message() throws Throwable {
    System.out.println("Balance is low");
}


}
