package com.capgemini.demos.formdef;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FormDef {
	
	private MyPageFactory fact;
	private WebDriver driver;
	
	@Given("^User in form page$")
	public void user_in_form_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new MyPageFactory(driver);
		driver.get("D:\\javaprograms\\demos\\src\\test\\java\\com\\capgemini\\demos\\formdef\\basicform.html");
	     
	}

	@When("^first name is empty$")
	public void first_name_is_empty() throws Throwable {
		fact.setUserName("");	     
	}

	@When("^submitting the form$")
	public void submitting_the_form() throws Throwable {
		fact.setButton();
	     
	}

	@Then("^display the error message$")
	public void display_the_error_message() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^city is empty$")
	public void city_is_empty() throws Throwable {
		fact.setUserName("Kishore arjun");
	    fact.setCity("");
	    Thread.sleep(2000);
	}
	
	@Then("^display the error message of city$")
	public void display_the_error_message_of_city() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	     
	}

	@When("^password is empty$")
	public void password_is_empty() throws Throwable {
		fact.setUserName("Kishore");
		fact.setCity("Chennai");
	    fact.setPassword("");
	    Thread.sleep(2000);
	}
	
	@Then("^display the error message of password$")
	public void display_the_error_message_of_password() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	     
	}

	@When("^Gender is not clicked$")
	public void gender_is_not_clicked() throws Throwable {
		fact.setUserName("Kishore");
		fact.setCity("Chennai");
		fact.setPassword("Root21@");
	    //fact.setRadiobtn(4);
		Thread.sleep(2000);
	}

	@Then("^display the error message of gender$")
	public void display_the_error_message_of_gender() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^language is not checked$")
	public void language_is_not_checked() throws Throwable {
		fact.setUserName("Kishore");
		fact.setCity("Chennai");
		fact.setPassword("Root@");
	    fact.setRadiobtn(fact.getRadiobtn());
	    //fact.setCheckbox(null);
	    Thread.sleep(2000);
	}

	@Then("^display the error message of language$")
	public void display_the_error_message_of_language() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^mynumber is empty$")
	public void mynumber_is_empty() throws Throwable {
		fact.setUserName("Kishore");
		fact.setCity("Chennai");
		fact.setPassword("Root");
	    fact.setRadiobtn(fact.getRadiobtn());
	    fact.setCheckbox(fact.getCheckbox());
	    fact.setMynumber("0");
	    Thread.sleep(2000);
	}

	@Then("^display the error message of mynumber$")
	public void display_the_error_message_of_mynumber() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^email is empty$")
	public void email_is_empty() throws Throwable {
		fact.setUserName("Kishore");
		fact.setCity("Chennai");
		fact.setPassword("Root@");
	    fact.setRadiobtn(fact.getRadiobtn());
	    fact.setCheckbox(fact.getCheckbox());
	    fact.setMynumber("30");
	    fact.setEmail("");
	    Thread.sleep(2000);
	}

	@Then("^display the error message of email$")
	public void display_the_error_message_of_email() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^mobile is empty$")
	public void mobile_is_empty() throws Throwable {
		fact.setUserName("Kishore arjun");
		fact.setCity("Chennai");
		fact.setPassword("Root");
	    fact.setRadiobtn(fact.getRadiobtn());
	    fact.setCheckbox(fact.getCheckbox());
	    fact.setMynumber("30");
	    fact.setEmail("kishore@gmail");
	    fact.setMobile("");
	    Thread.sleep(2000);
	}

	@Then("^display the error message of mobile$")
	public void display_the_error_message_of_mobile() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user entered all details$")
	public void user_entered_all_details() throws Throwable {
	    fact.setUserName("Kishore arjun");
	    fact.setCity("Chennai");
	    fact.setPassword("Root");
	    fact.setRadiobtn(fact.getRadiobtn());
	    fact.setCheckbox(fact.getCheckbox());
	    fact.setMynumber("30");
	    fact.setEmail("kishore@gmail.com");
	    fact.setMobile("96779142");
	    Thread.sleep(2000);
	}

	@When("^clicking the submit form$")
	public void clicking_the_submit_form() throws Throwable {
		fact.setButton();
	     
	}

	@Then("^display the success message$")
	public void display_the_success_message() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	    
	}
}
