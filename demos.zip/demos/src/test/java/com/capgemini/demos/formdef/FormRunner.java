package com.capgemini.demos.formdef;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"usage","html:html-output"},glue= {"com.capgemini.demos.formdef"})
public class FormRunner {

}
