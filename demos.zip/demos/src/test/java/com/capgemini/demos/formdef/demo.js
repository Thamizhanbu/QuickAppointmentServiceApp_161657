function chkEmpty(){
		var pass= /^[A-Za-z0-9]+[@]+[a-z0-9]+$/;
		//var names= /^[A-Z]([\\sA-za-z])+$/;
		var names=/^[A-Za-z ]*$/;
		var mob = /^[7-9]{1}[0-9]{9}$/;
		var email=/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;

		if (document.forms["frm1"]["userName"].value == "") {alert("Please fill the Name");}
		else if (names.test(document.frm1.userName.value)==false) {alert("Enter valid Name");}
		else if (document.frm1.city.value == "") {alert("Please fill the City");}
		else if (document.frm1.password.value == "") {alert("Please fill the Password");}
	    else if (pass.test(document.frm1.password.value)==false) {alert("Password must contain: 1.Uppercase,2.'@' special character,3.AlphaNumeric");}
		else if (!(document.getElementById('m').checked)&&!(document.getElementById('f').checked)){alert("Please click the gender");}
		else if (!(document.getElementById('eng').checked)&&!(document.getElementById('tel').checked)&&!(document.getElementById('tam').checked))
																									{alert("Please check the languages");}
		else if (document.frm1.number.value == "0"){alert("Please fill the MyNumber");}
		else if (document.frm1.email.value == ""){alert("Please fill the Email");}
		else if (email.test(document.frm1.email.value) == false) { alert("Please enter valid Email Id");}
		else if (document.frm1.mobile.value == "") {alert("Please fill the Mobile No.");}
		else if (mob.test(document.frm1.mobile.value) == false) { alert("Please enter valid Contact no");}
			else {
		alert(" completed Successfully");
//		window.location="success.html";
			}
		}