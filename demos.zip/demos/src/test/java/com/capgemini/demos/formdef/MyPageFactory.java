package com.capgemini.demos.formdef;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class MyPageFactory {

	WebDriver wd;

	// initiating Elements
	public MyPageFactory(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}

	@FindBy(how=How.NAME,using="userName")
	@CacheLookup
	WebElement userName;
	
	@FindBy(name = "city")
	@CacheLookup
	WebElement city;

	@FindBy(name = "password")
	@CacheLookup
	WebElement password;
	
	@FindBy(name="gender")
	@CacheLookup
	List<WebElement> radiobtn;
	
	@FindBy(name="lang")
	@CacheLookup
	List<WebElement> checkbox;
	
	@FindBy(name="number")
	@CacheLookup
	WebElement mynumber;
	
	@FindBy(name="email")
	@CacheLookup
	WebElement email;
	
	@FindBy(name="mobile")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(xpath="/html/body/form/input[14]")
	@CacheLookup
	WebElement button;

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public List<WebElement> getRadiobtn() {
		return radiobtn;
	}

	public void setRadiobtn(List<WebElement> radiobtn) {
		boolean value=radiobtn.get(0).isSelected();
		if(value==true) {
			radiobtn.get(0).click();
		}else {
			radiobtn.get(1).click();
		}
	}

	public List<WebElement> getCheckbox() {
		return checkbox;
	}

	public void setCheckbox(List<WebElement> checkbox) {
		int Size = checkbox.size();
	    for(int i=0; i < Size ; i++ ){
	    //checkbox.get(i).getAttribute("value");
	   if(i!=3){
	    checkbox.get(i).click();
	    }
	    }
	}
	
	public WebElement getMynumber() {
		return mynumber;
	}

	public void setMynumber(String mynumber) {
		this.mynumber.sendKeys(mynumber);;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}
	
	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}

}
