package com.capgemini.calculatordef;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CalculatorDef {
	
	@Given("^Calculator operation$")
	public void calculator_operation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Doing the Arithmetic Calculator operation");
		//throw new PendingException();
	}

	@Given("^assign the value of a and b as zero$")
	public void assign_the_value_of_a_and_b_as_zero() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Assigning the value of a and b as zero");
		//throw new PendingException();
	}

	@When("^Enter the value of a and b$")
	public void enter_the_value_of_a_and_b() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Entering the value of a and b");
		//throw new PendingException();
	}

	@When("^add the two values$")
	public void add_the_two_values() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Adding two values");
		//throw new PendingException();
	}

	@Then("^Displaying the output$")
	public void displaying_the_output() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Displaying the output");
		//throw new PendingException();
	}

	@When("^subtract the two values$")
	public void subtract_the_two_values() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Subtracting two values");
		//throw new PendingException();
	}

	@When("^multiply the two values$")
	public void multiply_the_two_values() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Multiplying two values");
		//throw new PendingException();
	}

	@When("^divide the two values$")
	public void divide_the_two_values() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Diving two values");
		//throw new PendingException();
	}

	@When("^assign (\\d+) and (\\d+) values to a and b$")
	public void assign_and_values_to_a_and_b(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Assigning the values a and b as "+arg1+" and "+arg2);
		//throw new PendingException();
	}

	@When("^doing the addition$")
	public void doing_the_addition() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Doing the Addition operation");
		//throw new PendingException();
	}

	@When("^doing the subtraction$")
	public void doing_the_subtraction() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Doing the Subtraction operation");
		//throw new PendingException();
	}

	@When("^doing the multiplying$")
	public void doing_the_multiplying() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Doing the Multiplying operation");
		//throw new PendingException();
	}

	@When("^doing the dividing$")
	public void doing_the_dividing() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Doing the Dividing operation");
		//throw new PendingException();
	}


	@Then("^displaying the output of (\\d+)$")
	public void displaying_the_output_of(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("The output of the operation is "+arg1);
		//throw new PendingException();
	}
	
}
