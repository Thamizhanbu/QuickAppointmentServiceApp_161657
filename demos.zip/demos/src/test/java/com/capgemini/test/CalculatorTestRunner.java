package com.capgemini.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"usage","json:jsonop/jsonfile"},glue= {"com.capgemini.calculatordef"})

public class CalculatorTestRunner {

}
