package com.capgemini.gamedef;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GameDef {
	
	@Given("^User is in game$")
	public void user_is_in_game() throws Throwable {
	    System.out.println("User is playing the game");
	     
	}

	@When("^User press the jump button$")
	public void user_press_the_jump_button() throws Throwable {
	    System.out.println("user is pressing the jump button");
	     
	}

	@Then("^Character should jump$")
	public void character_should_jump() throws Throwable {
	    System.out.println("Character is jumping");
	     
	}

	@When("^User press the Down button$")
	public void user_press_the_Down_button() throws Throwable {
	    System.out.println("user is pressing the down button");
	     
	}

	@Then("^Character should bend down$")
	public void character_should_bend_down() throws Throwable {
	    System.out.println("Character is bending down");
	     
	}

	@When("^User press the Right button$")
	public void user_press_the_Right_button() throws Throwable {
	    System.out.println("user is pressing the right button");
	     
	}

	@Then("^Character should move forward$")
	public void character_should_move_forward() throws Throwable {
	    System.out.println("character is moving forward");
	     
	}

	@When("^User press the Left button$")
	public void user_press_the_Left_button() throws Throwable {
	    System.out.println("user is pressing the left button");
	     
	}

	@Then("^Character should move backward$")
	public void character_should_move_backward() throws Throwable {
	    System.out.println("character is moving backward");
	     
	}

	@When("^User press the X button$")
	public void user_press_the_X_button() throws Throwable {
	    System.out.println("user is pressing the x button");
	    	     
	}

	@Then("^Character should fire$")
	public void character_should_fire() throws Throwable {
	    System.out.println("character is firing");
	     
	}

	@When("^User press the Y button$")
	public void user_press_the_Y_button() throws Throwable {
	    System.out.println("user is pressing the y button");
	     
	}

	@Then("^Character should jump and fire$")
	public void character_should_jump_and_fire() throws Throwable {
	    System.out.println("character is jumping and firing");
	     
	}

}
