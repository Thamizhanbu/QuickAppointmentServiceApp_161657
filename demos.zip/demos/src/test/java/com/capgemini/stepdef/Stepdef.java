package com.capgemini.stepdef;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	@Given("^I navigate to the login page$")
	public void i_navigate_to_the_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Navigating to Login Page");
		//throw new PendingException();
	}

	@Given("^Loads the login page$")
	public void loads_the_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Loading the login page");
		//throw new PendingException();
	}

	@When("^I enter the username and password$")
	public void i_enter_the_username_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Entering username and password");
		//throw new PendingException();
	}

	@Then("^I should be Logged in$")
	public void i_should_be_Logged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("User is Logged in");
		//throw new PendingException();
	}

	@Given("^User search for lenova laptop$")
	public void user_search_for_lenova_laptop() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("searching the lenova laptop");
		//throw new PendingException();
	}

	@When("^clicks the laptop$")
	public void clicks_the_laptop() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Selecting a laptop");
		//throw new PendingException();
	}

	@Then("^add the laptop in cart$")
	public void add_the_laptop_in_cart() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Laptop is added to the cart");
		//throw new PendingException();
	}


}
