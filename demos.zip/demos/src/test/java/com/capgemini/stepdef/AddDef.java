package com.capgemini.stepdef;

import cucumber.api.PendingException;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddDef {
	@When("^I give (\\d+) bananas to my friend$")
	public void i_give_bananas_to_my_friend(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^add (\\d+) bananas from my friend$")
	public void add_bananas_from_my_friend(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
