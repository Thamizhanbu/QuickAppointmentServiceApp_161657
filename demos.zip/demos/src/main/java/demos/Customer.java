package demos;

public class Customer {
	
	private String name;
	private String mobileno;
	private String city;
	private int balance;
	
	
	public Customer() {
		
	}
	
	
	public Customer(String name, String mobileno, String city, int balance) {
		super();
		this.name = name;
		this.mobileno = mobileno;
		this.city = city;
		this.balance = balance;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", mobileno=" + mobileno + ", city=" + city + ", balance=" + balance + "]";
	}
	

}
