package com.capgemini.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriverTest {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("https://www.google.com");
		System.out.println(wd.getTitle());
		/*String pageSource=wd.getPageSource();
		System.out.println(pageSource);*/
		//String parentwindow="https://www.webmail.com";
		System.out.println(wd.getCurrentUrl());
		//wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		//wd.navigate().to("https://www.tutorialspoint.com/");
		WebElement search=wd.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[1]/div/div[1]/input"));
		search.sendKeys("kishorejoker");
		//WebElement button=wd.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[3]/center/input[1]"));
		//button.click();
		search.submit();
		wd.navigate().back();
		//wd.switchTo().window(parentwindow);
		//wd.close();

	}

}
