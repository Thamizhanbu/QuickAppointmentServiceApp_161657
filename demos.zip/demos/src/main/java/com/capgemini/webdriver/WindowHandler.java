package com.capgemini.webdriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowHandler {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
				System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		    	WebDriver driver=new ChromeDriver();
		    	
		/*		File pathToBinary = new File("C:/Program Files/Mozilla Firefox/firefox.exe");
				FirefoxProfile firefoxProfile = new FirefoxProfile();
				FirefoxBinary binary = new FirefoxBinary(pathToBinary);
						
				WebDriver driver = new FirefoxDriver(binary,firefoxProfile);
				*/
				driver.get("file:///D:/javaprograms/CheckBox/checkbox.html");
				
				String parentWindow = driver.getWindowHandle().toString();
				System.out.println("ParentWindow -> "+parentWindow);
				
				driver.findElement(By.xpath("/html/body/form/input[9]")).click();
				WebDriver popup=driver.switchTo().window("PopupWindow");
				System.out.println("PopUp -> "+popup);
			//	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				Thread.sleep(2000);
				driver.close();
				
				driver.switchTo().window(parentWindow);
				
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				//driver.close(); 

	}

}
